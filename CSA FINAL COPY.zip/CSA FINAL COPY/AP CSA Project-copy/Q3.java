import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Q3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Q3 extends Blockers
{
    /**
     * Act - do whatever the Q3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Q3()
    {
        getImage().scale(getImage().getWidth()/3, getImage().getHeight()/3);
    }
    
    public void act() 
    {
        randomMovement();
        Q3();
    }    
}
